<div class="site-navbar-wrap js-site-navbar bg-white">
      
      <div class="container">
        <div class="site-navbar bg-light">
          <div class="py-1">
            <div class="row align-items-center">
              <div class="col-2">
                <h2 class="mb-0 site-logo"><a href="index.php">Online Home<strong class="font-weight-bold"> Services</strong> </a></h2>
              </div>
              <div class="col-10">
                <nav class="site-navigation" role="navigation">
                  <div class="container">
                    <div class="d-inline-block d-lg-none ml-md-0 mr-auto py-3"><a href="#" class="site-menu-toggle js-menu-toggle text-black"><span class="icon-menu h3"></span></a></div>

                    <ul class="site-menu js-clone-nav d-none d-lg-block">
					 <li><a href="mybooking.php">HOME</a></li>
                      <li><a href="profile.php">PROFILE</a></li>
                      <li><a href="changepassword.php">CHANGE PASSWORD</a></li>
                      
                      <li><a href="logout.php">Logout</a></li>
                      </ul>
                  </div>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>